import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faMagnifyingGlass } from '@fortawesome/free-solid-svg-icons'

function Searchbar(){

    return(


<div className="input-group">
          <input type='search' className="form-control rounded" placeholder="Search..."/>
          <button type='submit' className="btn btn-primary">
          <FontAwesomeIcon icon={faMagnifyingGlass} />
            </button>
            </div>

    );





}

export default Searchbar;