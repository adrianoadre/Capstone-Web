import Breadcrumb from 'react-bootstrap/Breadcrumb';

function StockcardForm(){
    return(
        <div className="row">
            <div className="col-2">
      
            </div>   
            <div className="col-8 guide">
            <Breadcrumb>
                <Breadcrumb.Item href="#">Home</Breadcrumb.Item>
                <Breadcrumb.Item href="https://getbootstrap.com/docs/4.0/components/breadcrumb/">
                    Library
                </Breadcrumb.Item>
                <Breadcrumb.Item active>Data</Breadcrumb.Item>
            </Breadcrumb>
            </div>
            <div className="col-2">
            </div>
        </div>

    );
}

export default StockcardForm;