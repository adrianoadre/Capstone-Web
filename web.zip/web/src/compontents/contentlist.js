import '../custom.css'

function Contentlist(){

    return(
        <ul className="list-group list-group-flush listcontainer bg-white guide">
            <li class="list-group-item">{1+2+3+1}</li>
            <li class="list-group-item">Cras justo odio</li>
            <li class="list-group-item">Cras justo odio</li>
        </ul>




    );
}

export default Contentlist;