import StockcardForm from "../compontents/stockcardform";

function InventoryPage(){
    return(
        <div>Inventory
         <StockcardForm />
        </div>

    );
}

export default InventoryPage;