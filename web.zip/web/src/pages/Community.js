function CommunityPage(){
    return(
        <div>Community
        </div>
        
    );
}

export default CommunityPage;