import Searchbar from "../compontents/searchbar";
import ContentList from "../compontents/contentlist";

function AnalyticsPage(){
    return(
        <div className="row">
            <h1 className="text-center">Analytics</h1>
            <div className="col-3">
                <Searchbar />
                <span><br></br></span>
                <ContentList />
            </div>
            
            <div className="col-9">
                
            </div>
        </div>

    );
}

export default AnalyticsPage;