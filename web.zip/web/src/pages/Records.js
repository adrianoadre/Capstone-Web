import Contentlist from "../compontents/contentlist";
import Searchbar from "../compontents/searchbar";
import TableData from "../compontents/table";


import Nav from 'react-bootstrap/Nav';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCalendarWeek, faNoteSticky, faPenToSquare } from '@fortawesome/free-solid-svg-icons'
import { ButtonGroup,Button } from "react-bootstrap";




function RecordsPage(){
    return(

        <div className="row bg-light">

            <div className="col-3 p-5">
                <Searchbar />
                <span><br /></span>
                <ButtonGroup aria-label="Basic example">
                <Button className="ButtonC" variant="primary">Add</Button>
                <Button className="ButtonC" variant="primary">Delete</Button>
                <Button className="ButtonC" variant="primary">Modify</Button>
                </ButtonGroup>

                <Contentlist />
            </div>

            <div className="col-9 p-5">
                <Nav fill variant="pills" defaultActiveKey="/home">
                    <Nav.Item>
                        <Nav.Link href="/home">Purchase History</Nav.Link>
                    </Nav.Item>
                    <Nav.Item>
                        <Nav.Link eventKey="link-1">Sales History</Nav.Link>
                    </Nav.Item>                  
                </Nav>
                <span><br></br></span>
                <div className="row px-5 py-3 bg-white">
                    <div className="row px-2 bg-white">
                        <small><FontAwesomeIcon icon={faPenToSquare} /> Document Number: </small>
                        <small><FontAwesomeIcon icon={faCalendarWeek} /> Date: </small>
                        <small><FontAwesomeIcon icon={faNoteSticky} /> Note: </small>
                    </div>
                    <span><br /></span>
                    <TableData />
                    
                </div>
              
            </div>



        </div>

    );
}

export default RecordsPage;