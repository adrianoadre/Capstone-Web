import { Route,Routes } from 'react-router-dom';

//pages
import AnalyticsPage from './pages/Analytics';
import CommunityPage from './pages/Community';
import InventoryPage from './pages/Inventory';
import RecordsPage from './pages/Records';
import Navigationbar from './layout/navigationbar';

import './custom.css'

function App() {



  return (
    <div>
      
      <Navigationbar />
      <Routes> 
            <Route path="/analytics" element={<AnalyticsPage />} />
            <Route path="/community" element={<CommunityPage />} />
            <Route path="/inventory" element={<InventoryPage />} />
            <Route path="/records" element={<RecordsPage />} />
      </Routes>

    </div>
  );
      

  

}

export default App;
